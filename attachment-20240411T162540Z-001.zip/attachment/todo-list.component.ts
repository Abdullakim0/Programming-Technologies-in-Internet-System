import { Component } from '@angular/core';

@Component({
  selector: 'app-todo-list',
  standalone: true,
  imports: [],
  templateUrl: './todo-list.component.html',
  styleUrl: './todo-list.component.css'
})
export class TodoListComponent {
  items=[
    { id: 1, name:'Take out trash'},
    { id: 2, name:'go shopping'},
   ];

}
