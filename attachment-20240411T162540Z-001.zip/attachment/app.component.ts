import { TodoListComponent } from './todo-list.component';
import { Component, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';

@NgModule({
  declarations: [
    TodoListComponent
  ],
})
@Component({
  selector: 'app-todo-list',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl:'./todo-list.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'cmd';
}
