const express = require('express');
const app = express();

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));

app.listen(3000, () => {
  console.log('Server listens on port 3000');
});

// Handling GET request to render the form
app.get('/', (req, res) => {
  res.render('index1.ejs');
});

// Handling POST request to display the entered data
app.post('/messages', (req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.write('<p>Data received from form.</p>');
  res.write('<p>' + req.body.name + ' ' + req.body.surname + '</p>');
  res.write('<p>' + req.body.message + '</p>');
  res.end();
});
