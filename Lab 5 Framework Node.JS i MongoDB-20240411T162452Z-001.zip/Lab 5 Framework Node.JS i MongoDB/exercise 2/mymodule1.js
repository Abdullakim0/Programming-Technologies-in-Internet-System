﻿exports.myDate = function () {
  return new Date().toLocaleString();
};
