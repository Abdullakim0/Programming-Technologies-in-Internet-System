const express = require('express');
const fs = require('fs');
const app = express();

app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.result = [];

app.listen(8080, () => {
  console.log('Listening on port 8080');
});

// Handling GET request to render the messages
app.get('/', (req, res) => {
  fs.readFile('messages.json', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      res.render('index', { messages: [] });
      return;
    }

    const messages = JSON.parse(data);
    res.render('index', { messages });
  });
});

// Handling POST request to add a new message
app.post('/messages', (req, res) => {
  const newMessage = {
    name: req.body.name,
    surname: req.body.surname,
    message: req.body.message,
    timestamp: new Date().toLocaleString(),
  };

  app.result.push(newMessage);
  fs.writeFile('messages.json', JSON.stringify(app.result), 'utf8', (err) => {
    if (err) {
      console.error(err);
      return;
    }
    console.log('Messages written to messages.json');
  });

  res.redirect('/');
});
