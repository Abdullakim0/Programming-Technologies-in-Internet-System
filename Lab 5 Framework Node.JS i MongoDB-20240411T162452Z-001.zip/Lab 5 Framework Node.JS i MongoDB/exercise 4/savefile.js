const fs = require('fs');
const textToSave = 'This text we are adding to the file!';

fs.appendFile('mojplik1.txt', textToSave, function (err) {
  if (err) throw err;
  console.log('File is saved!');
});
