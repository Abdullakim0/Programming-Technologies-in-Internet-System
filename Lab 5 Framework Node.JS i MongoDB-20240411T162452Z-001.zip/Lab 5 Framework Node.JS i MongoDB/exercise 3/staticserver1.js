﻿const http = require('http');
const fs = require('fs');

http.createServer((req, resp) => {
  console.log('Server got a request....');

  // Read the contents of the index.html file
  fs.readFile('./index.html', (error, content) => {
    if (error) {
      resp.writeHead(500);
      resp.end();
    } else {
      resp.writeHead(200, {
        'Content-Type': 'text/html'
      });
      resp.write(content);
      resp.end();
    }
  });
}).listen(3000);

console.log('Server started on port 3000');
